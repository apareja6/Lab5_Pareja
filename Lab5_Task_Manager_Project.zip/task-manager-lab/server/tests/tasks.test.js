import { after, before, test } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
const temp=mkdtempSync(join(tmpdir(),'task-manager-test-'));process.env.DATABASE_PATH=join(temp,'test.sqlite');
const {server}=await import('../src/app.js');
let base,id;
before(async()=>{await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));base=`http://127.0.0.1:${server.address().port}`;});
after(async()=>{await new Promise(resolve=>server.close(resolve));rmSync(temp,{recursive:true,force:true});});
async function req(path,method='GET',body){const res=await fetch(base+path,{method,headers:body?{'Content-Type':'application/json'}:{},body:body?JSON.stringify(body):undefined});return {status:res.status,body:res.status===204?null:await res.json()};}
test('health endpoint returns ok',async()=>{assert.deepEqual(await req('/api/health'),{status:200,body:{status:'ok'}});});
test('create validates input and returns contract-shaped task',async()=>{const r=await req('/api/tasks','POST',{title:'Write lab',description:'Complete phase 5',category:'School',priority:'high',dueDate:'2026-10-20'});assert.equal(r.status,201);assert.equal(r.body.title,'Write lab');assert.equal(r.body.isCompleted,false);assert.equal(typeof r.body.createdAt,'string');assert.equal(typeof r.body.id,'number');id=r.body.id;});
test('invalid task and category are rejected',async()=>{assert.equal((await req('/api/tasks','POST',{title:' ',category:'Unknown',priority:'urgent'})).status,400);assert.equal((await req('/api/tasks?category=Unknown')).status,400);});
test('category filter and completion update work',async()=>{const list=await req('/api/tasks?category=School');assert.equal(list.status,200);assert.equal(list.body.length,1);const update=await req(`/api/tasks/${id}`,'PATCH',{isCompleted:true});assert.equal(update.status,200);assert.equal(update.body.isCompleted,true);});
test('missing task returns 404 and delete persists',async()=>{assert.equal((await req('/api/tasks/99999')).status,404);assert.equal((await req(`/api/tasks/${id}`,'DELETE')).status,204);assert.equal((await req(`/api/tasks/${id}`)).status,404);});
