import { db } from '../config/database.js';
function map(row) { return row && ({ id:row.id, title:row.title, description:row.description, category:row.category, priority:row.priority, isCompleted:Boolean(row.is_completed), dueDate:row.due_date, createdAt:row.created_at, updatedAt:row.updated_at }); }
export const taskRepository = {
 list(category) { const rows = category ? db.prepare('SELECT * FROM tasks WHERE category = ? ORDER BY is_completed ASC, created_at DESC').all(category) : db.prepare('SELECT * FROM tasks ORDER BY is_completed ASC, created_at DESC').all(); return rows.map(map); },
 get(id) { return map(db.prepare('SELECT * FROM tasks WHERE id = ?').get(id)); },
 create(input) { const now=new Date().toISOString(); const result=db.prepare('INSERT INTO tasks(title,description,category,priority,due_date,created_at,updated_at) VALUES(?,?,?,?,?,?,?)').run(input.title,input.description??'',input.category,input.priority,input.dueDate??null,now,now); return this.get(Number(result.lastInsertRowid)); },
 update(id,input) { const old=this.get(id); if(!old)return undefined; const next={title:input.title??old.title,description:input.description??old.description,category:input.category??old.category,priority:input.priority??old.priority,dueDate:input.dueDate===undefined?old.dueDate:input.dueDate,isCompleted:input.isCompleted??old.isCompleted}; db.prepare('UPDATE tasks SET title=?,description=?,category=?,priority=?,due_date=?,is_completed=?,updated_at=? WHERE id=?').run(next.title,next.description,next.category,next.priority,next.dueDate,next.isCompleted?1:0,new Date().toISOString(),id); return this.get(id); },
 remove(id) { return db.prepare('DELETE FROM tasks WHERE id=?').run(id).changes>0; }
};
