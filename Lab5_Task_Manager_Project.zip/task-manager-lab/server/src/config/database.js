import { DatabaseSync } from 'node:sqlite';
import { mkdirSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
const path = resolve(process.env.DATABASE_PATH ?? './data/tasks.sqlite');
mkdirSync(dirname(path), { recursive: true });
export const db = new DatabaseSync(path);
db.exec(`PRAGMA journal_mode = WAL; PRAGMA foreign_keys = ON;
CREATE TABLE IF NOT EXISTS tasks (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 title TEXT NOT NULL CHECK(length(title) BETWEEN 1 AND 120),
 description TEXT NOT NULL DEFAULT '',
 category TEXT NOT NULL CHECK(category IN ('Work','Personal','School','Other')),
 priority TEXT NOT NULL CHECK(priority IN ('low','medium','high')),
 is_completed INTEGER NOT NULL DEFAULT 0 CHECK(is_completed IN (0,1)),
 due_date TEXT,
 created_at TEXT NOT NULL,
 updated_at TEXT NOT NULL
);`);
