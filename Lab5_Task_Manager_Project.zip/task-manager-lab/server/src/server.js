import { server } from './app.js';
const port=Number(process.env.PORT??3001);
server.listen(port,()=>console.log(`Task Manager API listening on http://localhost:${port}`));
