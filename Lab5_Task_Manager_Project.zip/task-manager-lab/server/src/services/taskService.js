import { taskRepository } from '../models/taskRepository.js';
export const categories=['Work','Personal','School','Other'];
export class HttpError extends Error { constructor(status,message){super(message);this.status=status;} }
export const taskService={
 list(category){if(category&&!categories.includes(category))throw new HttpError(400,'Invalid category filter.');return taskRepository.list(category);},
 get(id){const task=taskRepository.get(id);if(!task)throw new HttpError(404,'Task not found.');return task;},
 create(input){return taskRepository.create(input);},
 update(id,input){const task=taskRepository.update(id,input);if(!task)throw new HttpError(404,'Task not found.');return task;},
 remove(id){if(!taskRepository.remove(id))throw new HttpError(404,'Task not found.');}
};
