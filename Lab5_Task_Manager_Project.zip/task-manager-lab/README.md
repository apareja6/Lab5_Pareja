# Task Manager — Lab 5

A small full-stack task manager built with React + Vite, TypeScript, a modular Node.js HTTP API, and SQLite (Node 22's built-in `node:sqlite`). Tasks persist in a local database and can be created, viewed, edited, deleted, and filtered by category.

## Requirements
- Node.js 22.13+ (uses built-in `node:sqlite`)
- npm 10+

## Run locally
1. Copy `.env.example` to `server/.env` (or export the variables in your shell).
2. From this directory run `npm install`.
3. Run `npm run dev`. The frontend is at http://localhost:5173 and API at http://localhost:3001.
4. Run `npm test` for backend integration tests. After installing browsers with `npx playwright install chromium`, run `npm run test:e2e` with `npm run dev` running in another terminal. Run `npm run build` to type-check/build all workspaces.

The database is created automatically at `server/data/tasks.sqlite`. The server intentionally uses Node’s built-in HTTP module and SQLite to keep the backend runnable without third-party server dependencies. This is a learning MVP; for multi-instance production deployment, use PostgreSQL or another managed database, configure authentication, and add E2E browser tests in CI.

## API
- `GET /api/health` — health check
- `GET /api/tasks?category=Work` — list tasks, optionally filtered by category
- `POST /api/tasks` — create task (201)
- `GET /api/tasks/:id` — retrieve task (404 if absent)
- `PATCH /api/tasks/:id` — update task (404 if absent)
- `DELETE /api/tasks/:id` — delete task (204; 404 if absent)

## Architecture
`client` owns presentation and API calls; `server` owns HTTP, validation, business rules, and persistence; `shared` is the frontend/backend contract. See `docs/architecture.md`, `docs/contract.md`, and `docs/prompt-log.md`.
