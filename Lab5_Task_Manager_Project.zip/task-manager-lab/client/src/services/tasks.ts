import type { CreateTaskInput, Task, UpdateTaskInput, ApiError } from "@task-manager/contracts";
const BASE = "/api/tasks";
async function request<T>(url: string, init?: RequestInit): Promise<T> {
  const response = await fetch(url, { ...init, headers: { "Content-Type": "application/json", ...init?.headers } });
  if (!response.ok) { const body = await response.json().catch(() => ({ error: "Request failed" })) as ApiError; throw new Error(body.error || `HTTP ${response.status}`); }
  if (response.status === 204) return undefined as T;
  return response.json() as Promise<T>;
}
export const taskApi = {
  list: (category?: string) => request<Task[]>(`${BASE}${category ? `?category=${encodeURIComponent(category)}` : ""}`),
  create: (input: CreateTaskInput) => request<Task>(BASE, { method: "POST", body: JSON.stringify(input) }),
  update: (id: number, input: UpdateTaskInput) => request<Task>(`${BASE}/${id}`, { method: "PATCH", body: JSON.stringify(input) }),
  remove: (id: number) => request<void>(`${BASE}/${id}`, { method: "DELETE" })
};
