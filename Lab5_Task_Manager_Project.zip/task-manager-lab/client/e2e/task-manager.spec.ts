import { test, expect } from '@playwright/test';

test('user can create, complete, filter, and delete a task', async ({ page }) => {
  await page.goto('http://localhost:5173');
  await page.getByRole('button', { name: /new task/i }).click();
  await page.getByLabel('Title').fill('E2E lab task');
  await page.getByLabel('Category').selectOption('School');
  await page.getByLabel('Priority').selectOption('high');
  await page.getByRole('button', { name: 'Add task' }).click();
  await expect(page.getByRole('heading', { name: 'E2E lab task' })).toBeVisible();
  await page.getByRole('button', { name: 'Complete E2E lab task' }).click();
  await page.getByLabel('Filter by category').selectOption('School');
  await expect(page.getByRole('heading', { name: 'E2E lab task' })).toBeVisible();
  page.once('dialog', dialog => dialog.accept());
  await page.getByRole('button', { name: 'Delete E2E lab task' }).click();
  await expect(page.getByText('Nothing on your list')).toBeVisible();
});
