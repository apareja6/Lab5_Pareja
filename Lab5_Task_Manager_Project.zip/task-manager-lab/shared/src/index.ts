export const TASK_CATEGORIES = ["Work", "Personal", "School", "Other"] as const;
export type TaskCategory = (typeof TASK_CATEGORIES)[number];
export type TaskPriority = "low" | "medium" | "high";
export interface Task {
  id: number;
  title: string;
  description: string;
  category: TaskCategory;
  priority: TaskPriority;
  isCompleted: boolean;
  dueDate: string | null; // ISO 8601 date string or null
  createdAt: string; // ISO 8601 timestamp
  updatedAt: string; // ISO 8601 timestamp
}
export interface CreateTaskInput { title: string; description?: string; category: TaskCategory; priority: TaskPriority; dueDate?: string | null; }
export type UpdateTaskInput = Partial<CreateTaskInput> & { isCompleted?: boolean };
export interface ApiError { error: string; details?: string[]; }
