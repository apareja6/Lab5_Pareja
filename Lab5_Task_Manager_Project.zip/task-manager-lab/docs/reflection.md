# Lab 5 reflection

I acted as the architect by separating the application into a React client, an Express API, a shared contract package, and a persistence layer. I acted as the editor by reviewing component responsibilities, server validation, query patterns, and how database values are translated into API values rather than accepting generated code without inspection.

One example of the “majority problem” was the temptation to use a generic task-list query and filter results in application code. I improved this by validating category values and using a parameterized SQL filter so the database returns only matching tasks. I also addressed contract reliability: SQLite stores completion as an integer and uses snake_case columns, while the frontend expects a boolean and camelCase property names. A repository mapping normalizes these fields, and a shared TypeScript package documents the common contract.

The test suite covers health checks, task creation, validation failures, category filtering, updates, deletion, and missing resources. Before submission, I should run the tests and build, capture the real output, push the source to a version-controlled repository, and add browser-based end-to-end evidence. The current MVP does not include authentication and should not be presented as a fully secured public production service.
