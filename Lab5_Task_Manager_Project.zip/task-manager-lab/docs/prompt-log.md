# AI prompt log (chronological)

> This log records prompts and review decisions prepared for this lab. Update it with your actual tool interactions if your instructor expects a literal transcript.

## 1 — Architecture and scaffolding
**Prompt:** “Acting as a senior architect, generate a project structure for my selected application using a React frontend and Node.js backend. Provide a folder hierarchy that separates concerns, production-ready dependencies, and a clean development workflow.”
**Review:** Chose React/Vite/TypeScript, Express, a shared contract workspace, and a repository boundary. SQLite was selected for easy local persistence in a lab; PostgreSQL is a stronger managed production option.

## 2 — Frontend component design
**Prompt:** “Build a task form with title, description, category, priority, and due date. Define props, keep form state local, expose save/cancel callbacks, label all fields accessibly, and show validation errors.”
**Critique/revision:** Rather than mixing API calls into the form, the component receives `onSave` and `onCancel` callbacks. This keeps it reusable and allows the parent to handle create vs. update. Labels and alert roles were added.

## 3 — Backend API and persistence
**Prompt:** “Implement RESTful task CRUD endpoints with persistent storage, parameterized SQL, input validation, and meaningful HTTP status codes. Keep routes, controllers, services, and repository/data-access code separate.”
**Majority problem and improvement:** A generic first-pass implementation could load every task and filter categories in JavaScript or concatenate filter strings into SQL. This implementation uses a parameterized `WHERE category = ?` query, validates the category against the allowed enum, and rejects unsupported values. This reduces unnecessary reads and prevents SQL injection through the filter.

## 4 — Contract alignment
**Prompt:** “Create one shared Task contract for the React frontend and Node backend. Normalize database naming and types at the repository boundary and validate request bodies on the server.”
**Mismatch found and fix:** SQLite stores completion as integer `0/1` and uses snake_case columns, while React expects `isCompleted: boolean` and camelCase fields. The repository mapping converts these values before returning JSON; both workspaces import the shared `Task` type.

## 5 — Testing
**Prompt:** “Write automated tests for health, create, list/category filtering, invalid input, update, delete, and missing-resource responses. Use an isolated temporary database for repeatable tests.”
**Review:** Tests are written with Node's test runner and Supertest. Run `npm test` and include the real terminal output with the submission after dependencies are installed. Do not claim tests passed until you run them locally.
