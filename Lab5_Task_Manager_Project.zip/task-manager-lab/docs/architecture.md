# Architecture decisions

## Stack rationale
- **React + Vite + TypeScript:** component-driven UI, fast local feedback, static type checking.
- **Node.js HTTP API:** explicit request routing and response handling with no extra backend runtime dependency; modules still separate controllers, services, and persistence.
- **SQLite via Node 22 `node:sqlite`:** zero-service local persistent storage for a small lab MVP. The repository can later move to PostgreSQL through a repository/data-access boundary.
- **Shared TypeScript contract package:** centralizes category enums and Task/request types to reduce frontend/backend drift.
- **Zod:** validates untrusted request bodies on the server.
- **node:test + Supertest:** repeatable endpoint-level tests without a separate test runner configuration.

## Request lifecycle
React view → `client/src/services/tasks.ts` → Node HTTP handler → controller/input validation → task service/business rules → repository/prepared SQL → SQLite → contract-shaped JSON response.

## Separation of concerns
Components render UI; services perform HTTP requests; controllers translate HTTP to application calls; services enforce business rules; repository owns SQL; database configuration owns connection and schema initialization.

## Security and limitations
Queries use bound parameters; request bodies are size-limited; input schemas reject unknown fields; errors use consistent JSON. This educational MVP has no user accounts or authorization, so it is not suitable for exposing to the public internet with private user data. A production release should add authentication/ownership checks, rate limiting, Helmet, structured logging, CSRF protection if cookie sessions are used, managed database backups, and CI checks.
