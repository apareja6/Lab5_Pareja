# Frontend–backend contract

The shared source of truth is `shared/src/index.ts`, exported by `@task-manager/contracts`.

```ts
export interface Task {
  id: number;
  title: string;
  description: string;
  category: "Work" | "Personal" | "School" | "Other";
  priority: "low" | "medium" | "high";
  isCompleted: boolean;
  dueDate: string | null;
  createdAt: string; // ISO 8601 timestamp
  updatedAt: string; // ISO 8601 timestamp
}
```

Create input: `title` (trimmed, 1–120 chars), optional `description` (max 2,000 chars), required `category` and `priority`, optional nullable `dueDate` (`YYYY-MM-DD`). Update input accepts any non-empty subset of those fields plus `isCompleted`. Unknown request keys are rejected.

## Response behavior
- `200`: successful GET/PATCH; JSON `Task` or `Task[]`.
- `201`: task created; JSON `Task`.
- `204`: task deleted; no body.
- `400`: invalid identifier, category, or input; `{ "error": string, "details"?: string[] }`.
- `404`: missing task or route; `{ "error": string }`.
- `500`: unexpected server error; generic `{ "error": "Internal server error." }`.

Boolean fields remain booleans (`isCompleted` is not `0`/`1` in the API). Dates are ISO-compatible strings; SQL booleans and snake_case database fields are mapped at the repository boundary.
